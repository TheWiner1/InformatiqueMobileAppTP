package ca.ulaval.ima.tp2.ui.APropos;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import ca.ulaval.ima.tp2.R;

public class APropos extends Fragment{
    //private OnSimpleFragmentInteractionListener mListener;
    private Button importantBtn;
    private TextView aproposText;
    private StringBuilder text = new StringBuilder();


    public APropos() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.apropos_fragment, container, false);
//        final TextView textView = root.findViewById(R.id.text_home);

        //getActivity().setContentView (R.layout.apropos_fragment);
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(
                    new InputStreamReader(root.getContext().getAssets().open("a_propos.txt")));

            // do reading, usually loop until end of file reading
            String mLine;
            while ((mLine = reader.readLine()) != null) {
                text.append(mLine);
                text.append('\n');
            }
        } catch (IOException e) {
            //Toast.makeText(root.getApplicationContext(),"Error reading file!",Toast.LENGTH_LONG).show();
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    //log the exception
                }
            }

            TextView output = (TextView) root.findViewById(R.id.apropos_txt);
            output.setText((CharSequence) text);
        }
        return root;
    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        View view = inflater.inflate(R.layout.apropos_fragment, container, false);
////        importantBtn = view.findViewById(R.id.nav_aproposB);
////        importantBtn.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                mListener.onImportantButtonTouch();
////            }
////        });
//        return view;
//    }

//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//        if (context instanceof OnSimpleFragmentInteractionListener) {
//            mListener = (OnSimpleFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
//        }
//    }
//
//    @Override
//    public void onDetach() {
//        super.onDetach();
//        mListener = null;
//    }
//
//
//    public interface OnSimpleFragmentInteractionListener {
//        void onImportantButtonTouch();
//    }
}
