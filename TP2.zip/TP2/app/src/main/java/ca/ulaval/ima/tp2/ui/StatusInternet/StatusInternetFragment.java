package ca.ulaval.ima.tp2.ui.StatusInternet;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import ca.ulaval.ima.tp2.R;

public class StatusInternetFragment extends Fragment {
    //private OnSimpleFragmentInteractionListener mListener;
    private Button statusInternetButton;


    public StatusInternetFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.status_internet_fragment, container, false);
        final TextView textIndicator = root.findViewById(R.id.nav_statusInternetType);
        final ImageView indicator = root.findViewById(R.id.nav_statusInternetShape);
        final Context context = container.getContext();
        statusInternetButton = root.findViewById(R.id.nav_statusInternetBget);
        statusInternetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String state = StatusInternetViewModel.getConnectivityStatusString(context);
                int statei = StatusInternetViewModel.getConnectivityStatus(context);
                textIndicator.setText(state);
                textIndicator.setTextColor(Color.BLACK);

                if(state == "WI-FI" || state=="3G-LTE") {
                    //your code when wifi enable
                    indicator.setColorFilter(Color.GREEN);
                }
                else if(state=="NOTCONNECTED"){
                    indicator.setColorFilter(Color.RED);
                    //your code when no network connected
                }
            }
        });

        return root;
    }
}

