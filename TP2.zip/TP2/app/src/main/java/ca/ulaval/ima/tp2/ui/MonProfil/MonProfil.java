package ca.ulaval.ima.tp2.ui.MonProfil;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import ca.ulaval.ima.tp2.MainActivity;
import ca.ulaval.ima.tp2.R;

public class MonProfil extends Fragment {
 //   private OnSimpleFragmentInteractionListener mListener;
    private Button importantBtn;


    private TextView madescription;
    private StringBuilder text = new StringBuilder();

    TextView prenom, nom, dateNaissance, sexe, programme, description;
    private static MonProfilViewModel monprofil;
    public MonProfil() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.mon_profil_fragment, container, false);
//        final TextView textView = root.findViewById(R.id.text_home);

        prenom = root.findViewById(R.id.nav_monprofilPrenomVal);
        nom = root.findViewById(R.id.nav_monprofilNomVal);
        dateNaissance = root.findViewById(R.id.nav_monprofilDateNaisVal);
        sexe = root.findViewById(R.id.nav_monprofilSexeVal);
        programme = root.findViewById(R.id.nav_monprofilProgrammeVal);
        madescription = root.findViewById(R.id.nav_monprofilDescriptionText);

        monprofil = new MonProfilViewModel("Erwin",
                "Anoh", "1998-04-02", "Masculin", "GIF");

        if (this.getArguments() != null) {
//            monprofil = this.getArguments().getParcelable("parcel_user");
//
//            prenom.setText(monprofil.getM_prenom());
//            nom.setText(monprofil.getM_nom());
//            dateNaissance.setText(monprofil.getM_dateNaissance());
//            sexe.setText(monprofil.getM_sexe());
//            programme.setText(monprofil.getM_programme());
//        }
            String a = getArguments().getString("1");
            String b = getArguments().getString("2");
            String c = getArguments().getString("3");
            String d = getArguments().getString("4");
            String e = getArguments().getString("5");
            prenom.setText(a);
            nom.setText(b);
            dateNaissance.setText(c);
            sexe.setText(d);
            programme.setText(e);
        }

        BufferedReader reader = null;

        try {
            reader = new BufferedReader(
                    new InputStreamReader(root.getContext().getAssets().open("ma_description.txt")));

            // do reading, usually loop until end of file reading
            String mLine;
            while ((mLine = reader.readLine()) != null) {
                text.append(mLine);
                text.append('\n');
            }
        } catch (IOException e) {
            //Toast.makeText(root.getApplicationContext(),"Error reading file!",Toast.LENGTH_LONG).show();
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    //log the exception
                }
            }

            TextView output = (TextView) root.findViewById(R.id.nav_monprofilDescriptionText);
            output.setText((CharSequence) text);
        }


        return root;
    }


}