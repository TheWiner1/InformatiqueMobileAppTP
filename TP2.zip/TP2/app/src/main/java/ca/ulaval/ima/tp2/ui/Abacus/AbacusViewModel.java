package ca.ulaval.ima.tp2.ui.Abacus;

import androidx.lifecycle.ViewModel;

public class AbacusViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
