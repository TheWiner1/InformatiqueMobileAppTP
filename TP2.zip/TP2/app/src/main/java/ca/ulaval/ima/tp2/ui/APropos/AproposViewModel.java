package ca.ulaval.ima.tp2.ui.APropos;

import androidx.lifecycle.ViewModel;

public class AproposViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
