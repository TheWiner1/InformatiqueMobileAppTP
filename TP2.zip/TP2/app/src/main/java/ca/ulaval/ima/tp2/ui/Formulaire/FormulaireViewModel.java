package ca.ulaval.ima.tp2.ui.Formulaire;

import androidx.lifecycle.ViewModel;

public class FormulaireViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
