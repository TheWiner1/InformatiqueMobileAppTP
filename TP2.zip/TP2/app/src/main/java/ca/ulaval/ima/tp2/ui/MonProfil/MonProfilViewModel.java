package ca.ulaval.ima.tp2.ui.MonProfil;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.lifecycle.ViewModel;

public class MonProfilViewModel extends ViewModel implements Parcelable {

    public final static Parcelable.Creator<MonProfilViewModel> CREATOR = new
            Parcelable.Creator<MonProfilViewModel>() {
                public MonProfilViewModel createFromParcel(Parcel in) {
                    return new MonProfilViewModel(in);
                }

                public MonProfilViewModel[] newArray(int size) {
                    return new MonProfilViewModel[size];
                }
            };
    private String m_prenom;
    private String m_nom;
    private String m_dateNaissance;
    private String m_sexe;
    private String m_programme;

    public MonProfilViewModel(String p_prenom, String p_nom, String p_dateNaissance,
                              String p_sexe, String p_programme) {

    }

    public MonProfilViewModel(Parcel source) {
        if (source.dataSize() > 0) {
            this.m_nom = source.readString();
            this.m_prenom = source.readString();
            this.m_dateNaissance = source.readString();
            this.m_sexe = source.readString();
            this.m_programme = source.readString();
//            this.m_dateNaissance = (java.util.Date) source.readSerializable();

        }
    }

    public String getM_prenom() {
        return m_prenom;
    }

    public void setM_prenom(String m_prenom) {
        this.m_prenom = m_prenom;
    }

    public String getM_nom() {
        return m_nom;
    }

    public void setM_nom(String m_nom) {
        this.m_nom = m_nom;
    }

    public String getM_dateNaissance() {
        return m_dateNaissance;
    }

    public void setM_dateNaissance(String m_dateNaissance) {
        this.m_dateNaissance = m_dateNaissance;
    }

    public String getM_sexe() {
        return m_sexe;
    }

    public void setM_sexe(String m_sexe) {
        this.m_sexe = m_sexe;
    }

    public String getM_programme() {
        return m_programme;
    }

    public void setM_programme(String m_programme) {
        this.m_programme = m_programme;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.m_nom);
        dest.writeString(this.m_prenom);
        dest.writeSerializable(this.m_dateNaissance);
        dest.writeString(this.m_sexe);
        dest.writeString(this.m_programme);
    }
}
