package ca.ulaval.ima.tp2.ui.Formulaire;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import ca.ulaval.ima.tp2.MainActivity;
import ca.ulaval.ima.tp2.R;
import ca.ulaval.ima.tp2.ui.Activity2;
import ca.ulaval.ima.tp2.ui.MonProfil.MonProfil;
import ca.ulaval.ima.tp2.ui.MonProfil.MonProfilViewModel;

public class Formulaire extends Fragment implements DatePickerDialog.OnDateSetListener {
    //private OnSimpleFragmentInteractionListener mListener;
    private Button soumettre;
    private RadioGroup radioGroupSexe;
    private String nnom, pprenom, date, sexVal, programme;
    private RadioButton sexe;

    private MonProfilViewModel profil;

    public Formulaire() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    public void setNom(String nom) {
        this.nnom = nom;
    }

    public void setPrenom(String prenom) {
        this.pprenom = prenom;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             final ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.formulaire_fragment, container, false);

///1111//////////////////////////////////////////////////////////////////////////////////////////////////////
        final EditText prenom = root.findViewById(R.id.nav_formulaireEditPrénom);
 //       prenom.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView textView, int actionId,
//                                          KeyEvent keyEvent) {
//                if (actionId == EditorInfo.IME_ACTION_DONE){
//                    Log.d("demo","MyWork is done here!, Text:"+textView.getText().toString());
//                    return true;
//                }
//                return false;
//            }
//        });
        setPrenom(prenom.getText().toString());
///2222//////////////////////////////////////////////////////////////////////////////////////////////////////
        final EditText nom = root.findViewById(R.id.nav_formulaireEditNom);
 //       prenom.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView textView, int actionId,
//                                          KeyEvent keyEvent) {
//                if (actionId == EditorInfo.IME_ACTION_DONE){
//                    Log.d("demo","MyWork is done here!, Text:"+textView.getText().toString());
//                    return true;
//                }
//                return false;
//            }
//        });
        setNom(nom.getText().toString());

///3333//////////////////////////////////////////////////////////////////////////////////////////////////////


        final EditText dateNais = root.findViewById(R.id.nav_formulaireEditDateNaissance);
  //      prenom.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView textView, int actionId,
//                                          KeyEvent keyEvent) {
//                if (actionId == EditorInfo.IME_ACTION_DONE){
// //                   Log.d("demo","MyWork is done here!, Text:"+textView.getText().toString());
//                    return true;
//                }
//                return false;
//            }
//        });

        final DatePickerDialog datePickerDialog = new DatePickerDialog(container.getContext(),
                new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                DateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.CANADA_FRENCH);
                dateNais.setText(df.format(newDate.getTime()));
            }
        }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH));

        dateNais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePickerDialog.show();
            }
        });

        setDate(dateNais.getText().toString());

///4444//////////////////////////////////////////////////////////////////////////////////////////////////////

        radioGroupSexe = (RadioGroup) root.findViewById(R.id.nav_formulaireRadioGroup);
        radioGroupSexe.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int
                    identifier) {
                if(identifier == R.id.radioMasculin){
//                    Log.d("demo","Monday selected");
                    setSexe("Masculin");
                }
                if(identifier == R.id.radioFeminin){
//                    Log.d("demo","Monday selected");
                    setSexe("Feminin");
                }
            }
        });
        radioGroupSexe.getCheckedRadioButtonId();
///5555//////////////////////////////////////////////////////////////////////////////////////////////////////

        Spinner programmespinner = (Spinner) root.findViewById(R.id.nav_formulaireSpinnerProgramme);
        String[] programmes={"GEL","GIF","GLO", "IFT"};
        ArrayAdapter daysAdapter =  new ArrayAdapter(root.getContext(), android.R.layout.simple_spinner_item,programmes);
        programmespinner.setAdapter(daysAdapter);

        programmespinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long identifier) {

                switch (position){
                    case 0:
//                        Log.d("demo","Monday!");
                        setProgramme("GEL");
                        break;
                    case 1:
                        //Log.d("demo","Tuesday!");
                        setProgramme("GIF");
                        break;
                    case 2:
                        //Log.d("demo","Wednesday!");
                        setProgramme("GLO");
                        break;
                    case 3:
                        //Log.d("demo","Wednesday!");
                        setProgramme("IFT");
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
/////////////////////////////////////////////////////////////////////////////////////////////////////0


        profil = new MonProfilViewModel(pprenom, nnom, date, sexVal, programme);

        soumettre = root.findViewById(R.id.nav_formulaireSoumettre);
        soumettre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  if (this.isFormValid(view)) {
                    Bundle bundle = new Bundle();
                    bundle.putParcelable("parcel_user", profil);
                    bundle.putString("1", nnom);
                    bundle.putString("2", pprenom);
                    bundle.putString("3", date);
                    bundle.putString("4", sexVal);
                    bundle.putString("5", programme);
                    Fragment fragment = new MonProfil();
                    fragment.setArguments(bundle);

                    if (getActivity() != null) {
                        FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.nav_host_fragment, fragment);
                        //ft.addToBackStack( "tag" ).commit();
                        ft.commit();
                    }
//                Intent intent = new Intent(container.getContext(), Activity2.class);
//                intent.putExtra("monProfil", getProfil());
//                startActivity(intent);

                }
           // }
        });

        return root;
    }

    public void setProgramme(String p_programme){
        programme = p_programme;
    }

    public MonProfilViewModel getProfil() {
        return profil;
    }

    public void setSexe(String p_sexe){
        sexVal = p_sexe;
    }
    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
    }

}
