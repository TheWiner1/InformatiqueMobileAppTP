package ca.ulaval.ima.tp2.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import ca.ulaval.ima.tp2.R;
import ca.ulaval.ima.tp2.ui.MonProfil.MonProfilViewModel;

public class Activity2 extends AppCompatActivity {

    TextView prenom, nom, dateNaissance, sexe, programme;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        prenom = findViewById(R.id.nav_monprofilPrenomVal);
        nom = findViewById(R.id.nav_monprofilNomVal);
        dateNaissance = findViewById(R.id.nav_monprofilDateNaisVal);
        sexe = findViewById(R.id.nav_monprofilSexeVal);
        programme = findViewById(R.id.nav_monprofilProgrammeVal);

        Intent intent = getIntent();
        MonProfilViewModel moiMeme = intent.getParcelableExtra("monProfil");

        prenom.setText(moiMeme.getM_prenom());
        nom.setText(moiMeme.getM_nom());
        dateNaissance.setText(moiMeme.getM_dateNaissance());
        sexe.setText(moiMeme.getM_sexe());
        programme.setText(moiMeme.getM_programme());

    }
}
