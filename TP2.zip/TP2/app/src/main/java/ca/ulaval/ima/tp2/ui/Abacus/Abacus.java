package ca.ulaval.ima.tp2.ui.Abacus;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import ca.ulaval.ima.tp2.R;

public class Abacus extends Fragment {
    //  private OnSimpleFragmentInteractionListener mListener;
    private Button importantBtn;

    public Abacus() {
    }

    SeekBar seekBar1, seekBar2, seekBar3;
    int val3=1;
    int val1=1;
    int val2=1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //   initiate  views


    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.abacus_fragment, container, false);

        final TextView val1text = root.findViewById(R.id.nav_abacus1Val);
        final TextView val2text = root.findViewById(R.id.nav_abacus2Val);
        final TextView val3text = root.findViewById(R.id.nav_abacus3Val);


        seekBar1 =(SeekBar)root.findViewById(R.id.nav_abacusBAR1);
        seekBar2 =(SeekBar)root.findViewById(R.id.nav_abacusBAR2);
        seekBar3 =(SeekBar)root.findViewById(R.id.nav_abacusBAR3);
        // perform seek bar change listener event used for getting the progress value



        seekBar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                val1 = progress;
                val1text.setText(Integer.toString(val1));
                val3 = val2*val1;
                val3text.setText(Integer.toString(val3));


                seekBar3.setProgress(val3);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                val2 = progress;
                val2text.setText(Integer.toString(val2));
                val3 = val2*val1;
                val3text.setText(Integer.toString(val3));

                seekBar3.setProgress(val3);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        seekBar1.setProgress(val1);
        seekBar2.setProgress(val2);
        seekBar3.setProgress(val3);
//
//        int seekBarProgress = seekBar1.getProgress();



        return root;
    }

//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        View view = inflater.inflate(R.layout.abacus_fragment, container, false);
//        importantBtn = view.findViewById(R.id.nav_abacusB);
//        importantBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                mListener.onImportantButtonTouch();
//            }
//        });
//        return view;
//    }

//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//        if (context instanceof OnSimpleFragmentInteractionListener) {
//            mListener = (OnSimpleFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
//        }
//    }
//
//    @Override
//    public void onDetach() {
//        super.onDetach();
//        mListener = null;
//    }
//
//    public interface OnSimpleFragmentInteractionListener {
//        void onImportantButtonTouch();
//    }
}