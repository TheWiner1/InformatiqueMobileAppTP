package ca.ulaval.ima;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

import com.example.tp1.R;

public class WebViewActivity extends AppCompatActivity {

    private WebView webView;
    private Button b_fermWebV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.webviewAlabel);
        setContentView(R.layout.activity_web_view);

        b_fermWebV = findViewById(R.id.button6);

        Intent intent = getIntent();

        webView = findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient());
        //webView.loadUrl(intent.getStringExtra("url"));
        webView.loadUrl(webView.getResources().getString(R.string.url));

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        b_fermWebV.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
