package ca.ulaval.ima;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.tp1.R;

public class UlavalActivity extends AppCompatActivity {
    private Button b_fermerUL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.ulavalAlabel);
        setContentView(R.layout.activity_ulaval);

        b_fermerUL = findViewById(R.id.button5);

        b_fermerUL.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
    }
}
