package ca.ulaval.ima;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import android.view.View;
import android.widget.Button;

import com.example.tp1.R;

public class MainActivity extends AppCompatActivity {

    private Profil moiMeme;
    private String UrlToLoad;

    private Button b_monProfil, b_siteExt, b_siteWebV, b_Ulaval;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b_monProfil = findViewById(R.id.button);
        b_siteExt = findViewById(R.id.button2);
        b_siteWebV = findViewById(R.id.button3);
        b_Ulaval = findViewById(R.id.button4);

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

        try {
            moiMeme = new Profil("Anoh", "Ervin", format.parse("1998-04-02"), "ANANB");
        } catch (ParseException e) {
            e.printStackTrace();
        }

        UrlToLoad = "https://www.scan-fr.co/";

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.putExtra("url", UrlToLoad);

        b_monProfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMonprofil();
            }
        });

        b_siteExt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSiteExt();
            }
        });

        b_siteWebV.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openSiteWebV();
            }
        });
        b_Ulaval.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openULaval();
            }
        });

    }

    public void openMonprofil() {
        Intent intent = new Intent(this, ProfilActivity.class);
        intent.putExtra("monProfil", moiMeme);
        startActivity(intent);

    }

    public void openSiteExt() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(UrlToLoad));
        startActivity(intent);
    }

    public void openULaval() {
        Intent intent = new Intent(this, UlavalActivity.class);
        startActivity(intent);
    }

    public void openSiteWebV() {
        Intent intent = new Intent(this, WebViewActivity.class);
        startActivity(intent);
    }

    public String getUrlToLoad() {
        return UrlToLoad;
    }

    public Profil getMoiMeme() {
        return moiMeme;
    }

}
