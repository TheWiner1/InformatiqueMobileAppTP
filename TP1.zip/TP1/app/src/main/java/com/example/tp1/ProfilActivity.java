package com.example.tp1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ProfilActivity extends AppCompatActivity {

    private TextView tv_nom, tv_prenom, tv_dateNaissance,tv_IDUL;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.profilAlabel);
        setContentView(R.layout.activity_profil);

        tv_nom = findViewById(R.id.textView5);
        tv_prenom = findViewById(R.id.textView6);
        tv_dateNaissance = findViewById(R.id.textView7);
        tv_IDUL = findViewById(R.id.textView8);

        Intent intent = getIntent();
        Profil moiMeme = intent.getParcelableExtra("monProfil");

        tv_nom.setText(moiMeme.getNom());
        tv_prenom.setText(moiMeme.getPrenom());
        tv_dateNaissance.setText(moiMeme.getDateNaissance().toString());
        tv_IDUL.setText(moiMeme.getIdul());

    }
}
