package com.example.tp1;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;


public class Profil implements Parcelable{

    public Profil(String p_nom, String p_prenom, Date p_dateNaissance, String p_idul){
        this.m_nom = p_nom;
        this.m_prenom = p_prenom;
        this.m_dateNaissance = p_dateNaissance;
        this.m_idul = p_idul;
    }

    private String m_nom, m_prenom;
    private Date m_dateNaissance;
    private String m_idul;

    public String getNom() {
        return m_nom;
    }

    public String getPrenom() {
        return m_prenom;
    }

    public Date getDateNaissance() {
        return m_dateNaissance;
    }

    public String getIdul() {
        return m_idul;
    }

    public void setNom(String p_nom) {
        this.m_nom = p_nom;
    }

    public void setPrenom(String p_prenom) {
        this.m_prenom = p_prenom;
    }

    public void setDateNaissance(Date p_dateNaissance) {
        this.m_dateNaissance = p_dateNaissance;
    }

    public void setIdul(String p_idul) {
        this.m_idul = p_idul;
    }


    public Profil(Parcel source) {
        if (source.dataSize()>0){
            this.m_nom = source.readString();
            this.m_prenom = source.readString();
            this.m_dateNaissance = (java.util.Date) source.readSerializable();
            this.m_idul = source.readString();
        }
    }

    public final static Parcelable.Creator<Profil> CREATOR = new
            Parcelable.Creator<Profil>() {
                public Profil createFromParcel(Parcel in) {
                    return new Profil(in);
                }

                public Profil[] newArray(int size) {
                    return new Profil[size];
                }
            };
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.m_nom);
        dest.writeString(this.m_prenom);
        dest.writeSerializable(this.m_dateNaissance);
        dest.writeString(this.m_idul);
    }
}
