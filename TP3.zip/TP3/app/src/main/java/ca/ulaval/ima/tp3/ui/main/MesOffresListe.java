package ca.ulaval.ima.tp3.ui.main;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.InputStream;
import java.util.List;

import ca.ulaval.ima.tp3.R;
import ca.ulaval.ima.tp3.VendreActivity;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MesOffresListe#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MesOffresListe extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private List<Country> countryList;
    private RecyclerView mRecyclerView;
    private CountryRecyclerViewAdapter adapter;


    public MesOffresListe() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MesOffresListe.
     */
    // TODO: Rename and change types and number of parameters
    public static MesOffresListe newInstance(String param1, String param2) {
        MesOffresListe fragment = new MesOffresListe();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        // get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();

        // inflate and set the layout for the dialog
        // pass null as the parent view because its going in the dialog layout
        builder.setView(inflater.inflate(R.layout.dialog_signin, null))

                // action buttons
                .setPositiveButton("Login", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // your sign in code here

                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // remove the dialog from the screen
                    }
                })
                .show();



    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment



        final View root = inflater.inflate(R.layout.fragment_country, container, false);


        mRecyclerView = (RecyclerView) root.findViewById(R.id.recycler_viewOffres);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(root.getContext()));
        //mRecyclerView.setLayoutManager(new GridLayoutManager(this));

        MesOffresParser mesOffresParser = new MesOffresParser();
        InputStream inputStream = getResources().openRawResource(R.raw.countries);
        mesOffresParser.parse(inputStream);
        List<Country> countryList = mesOffresParser.getList();

        adapter = new CountryRecyclerViewAdapter(root.getContext(), countryList);
        mRecyclerView.setAdapter(adapter);
        adapter.setOnCountryClickListener(new CountryRecyclerViewAdapter.OnCountryClickListener() {
            @Override
            public void onCountryClick(Country item) {
                //Toast.makeText(root.getContext(), item.name, Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getActivity(), VendreActivity.class);
                startActivity(intent);
            }
        });
        return root;
    }

}
