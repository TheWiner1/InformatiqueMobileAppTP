package ca.ulaval.ima.tp3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Constraints;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Layout;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DescriptionOffre extends AppCompatActivity {


    private RequestQueue mQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description_offre);

        mQueue = Volley.newRequestQueue(this);


        //String url = "http://68.183.207.74/api/v1/offer/";
        final Intent intent = getIntent();
        final String id = intent.getStringExtra("id_model");
        int id2 = Integer.parseInt(id);
        String url = "http://68.183.207.74/api/v1/offer/" + id2 + "" + "/details/";
        final TextView  year_tv, klmt_tv, price_tv, name_tv;
        year_tv = findViewById(R.id.year_tv);
        klmt_tv = findViewById(R.id.klmt_tv);
        price_tv = findViewById(R.id.price_tv);
        name_tv = findViewById(R.id.name_tv);
        final String[] marque_tv = new String[1];
        final String[] modele_tv = new String[1];
        final String[] annee_tv = new String[1];
        final String[] klmt_tv2 = new String[1];
        final String transm_tv;
        final String[] prix_tv = new String[1];
        final String[] vendeur_tv = new String[1];
        final String[] propr_tv = new String[1];
        final String[] desc_tv = new String[1];
        final String[] urimg = new String[1];

        final ImageView img = findViewById(R.id.ImageDescOffre);

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String name1, name2, year, klmt, price;
                            //JSONArray jsonArray_modele_desc = response.getJSONArray("content");

                           // for (int i = 0 ; i < jsonArray_modele_desc.length(); i++){
                            JSONObject desc = response.getJSONObject("content");
                            name1 = desc.getJSONObject("model").getString("name");
                            name2 = desc.getJSONObject("model").getJSONObject("brand").getString("name");
                            year = desc.getInt("year") + "";
                            klmt = desc.getInt("kilometers") + "";
                            price = desc.getInt("price") + "";

                            urimg[0] = desc.getString("image");

                            Picasso.get().load(urimg[0]).into(img);


                            getSupportActionBar().setTitle(name2 + " " + name1);
                            name_tv.setText(name2 + " " + name1);
                            year_tv.setText(year);
                            klmt_tv.setText(klmt + " km");
                            price_tv.setText(price + "$");


                            String vendeur_last_name, vendeur_first_name, email;
                            boolean prop;

                            vendeur_last_name = desc.getJSONObject("seller").getString("last_name");
                            vendeur_first_name = desc.getJSONObject("seller").getString("first_name");
                            email = desc.getJSONObject("seller").getString("email");
                            prop = desc.getBoolean("from_owner");


                            if(prop){
                                propr_tv[0] = "Oui";
                            }else{
                                propr_tv[0] = "Non";
                            }
                            marque_tv[0] = name2;
                            modele_tv[0] = name1;
                            annee_tv[0] = year;
                            klmt_tv2[0] = klmt;
                            prix_tv[0] = price;
                            vendeur_tv[0] = vendeur_last_name + vendeur_first_name;
                            desc_tv[0] = desc.getString("description");
                            Intent intent = getIntent();


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);


        ConstraintLayout layout = findViewById(R.id.descoffre);

        layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DescriptionOffre.this, VendreActivity.class);
                intent.putExtra("prop", propr_tv[0]);
                intent.putExtra("marque_tv", marque_tv[0]);
                intent.putExtra("modele_tv", modele_tv[0]);
                intent.putExtra("annee_tv", annee_tv[0]);
                intent.putExtra("klmt_tv", klmt_tv2[0]);
                intent.putExtra("prix_tv", prix_tv[0]);
                intent.putExtra("vendeur_tv", vendeur_tv[0]);
                intent.putExtra("desc_tv", desc_tv[0]);
                intent.putExtra("urimg", urimg[0]);
                startActivity(intent);
            }
        });

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
