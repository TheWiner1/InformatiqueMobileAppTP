//package ca.ulaval.ima.tp3.ui.main;
//
//import android.os.AsyncTask;
//
//public class RequetesHTTP extends AsyncTask {
//}
