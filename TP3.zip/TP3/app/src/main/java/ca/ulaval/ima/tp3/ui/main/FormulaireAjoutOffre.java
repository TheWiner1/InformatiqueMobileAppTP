package ca.ulaval.ima.tp3.ui.main;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ca.ulaval.ima.tp3.DescriptionOffre;
import ca.ulaval.ima.tp3.ListeModelesActivity;
import ca.ulaval.ima.tp3.ListeModelesAllActivity;
import ca.ulaval.ima.tp3.R;
import ca.ulaval.ima.tp3.VendreActivity;

public class FormulaireAjoutOffre extends Fragment {

    private FormulaireAjoutOffreViewModel mViewModel;

    public static FormulaireAjoutOffre newInstance() {
        return new FormulaireAjoutOffre();
    }

    private String m_Text = "";
    private String m_Text2 = "";

    private RequestQueue mQueue;

    private StringBuilder text = new StringBuilder();

    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        final View root = inflater.inflate(R.layout.formulaire_ajout_offre_fragment, container, false);


        Button btn_models =  root.findViewById(R.id.nommodeleForm);
        Button btn_submit =  root.findViewById(R.id.form_submit);

        btn_models.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), ListeModelesAllActivity.class);
                startActivity(intent);
            }
        });

//        Intent intent = getActivity().getIntent();
//       String model_txt = intent.getStringExtra("modl");

        BufferedReader reader = null;

        try {
            reader = new BufferedReader(
                    new InputStreamReader(root.getContext().getAssets().open("modele_valeur.txt")));

            // do reading, usually loop until end of file reading
            String mLine;
            while ((mLine = reader.readLine()) != null) {
                text.append(mLine);
                text.append('\n');
            }
        } catch (IOException e) {
            //Toast.makeText(root.getApplicationContext(),"Error reading file!",Toast.LENGTH_LONG).show();
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    //log the exception
                }
            }
            btn_models.setText((CharSequence) text);

        }


        //final String[] prix = new String[1];
        /////////////////////////////////////////////////
        EditText prix_ed = root.findViewById(R.id.form_prix);
        final String prix = prix_ed.getText().toString();
//        prix_ed.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView textView, int actionId,
//                                          KeyEvent keyEvent) {
//                if (actionId == EditorInfo.IME_ACTION_DONE){
//                    prix[0] = textView.getText().toString();
//                    return true;
//                }
//                return false;
//            }
//        });
        //////////////////////////////////////////////////////////////////////////////////////////////////
//        final String[] klmn = new String[1];
        //////////////////////////////////////////////////////////////////////////////////////////////////
        EditText klmn_ed = root.findViewById(R.id.form_prix);
        final String klmn = klmn_ed.getText().toString();
        //        klmn_ed.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView textView, int actionId,
//                                          KeyEvent keyEvent) {
//                if (actionId == EditorInfo.IME_ACTION_DONE){
//                    klmn[0] = textView.getText().toString();
//                    return true;
//                }
//                return false;
//            }
//        });
/////////////////////////////////////////////////

        Spinner spin_annees = (Spinner) root.findViewById(R.id.form_annee);

        final List<String> list_annee = Arrays.asList(
//                "1999", "2000", "2001",
//                "2002", "2003", "2004",
//                "2005", "2006", "2007",
//                "2008", "2009", "2010",
//                "2011", "2012", "2013",
//                "2014", "2015", "2016",
                "2018", "2019",
                "2020");//new ArrayList<String>();


        ArrayAdapter daysAdapter =  new ArrayAdapter(root.getContext(), android.R.layout.simple_spinner_item, list_annee);
        spin_annees.setAdapter(daysAdapter);
        final String[] annee = new String[1];

        spin_annees.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long identifier) {
                    annee[0] = list_annee.get(position);
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
////////////////////////////////////////////////////////////////////////////////////////

        Spinner spin_transm = (Spinner) root.findViewById(R.id.form_typetransmission);

        final List<String> transm_list = Arrays.asList("Manuel", "Semi-automatique", "Automatique");
        ArrayAdapter transm_adapater =  new ArrayAdapter(root.getContext(), android.R.layout.simple_spinner_item, transm_list);
        spin_transm.setAdapter(transm_adapater);

        final String[] transmission = new String[1];

        spin_annees.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long identifier) {
                transmission[0] = transm_list.get(position);
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
////////////////////////////////////////////////////////////////////////////////////////

        final String vendu_own;
        CheckBox check = root.findViewById(R.id.form_vendu_checkbox);
        if(check.isChecked())
            vendu_own = "oui";
        else
            vendu_own = "non";


////////////////////////////////////////////////////////////////////////////////////////


        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

                // get the layout inflater
                LayoutInflater inflater = getActivity().getLayoutInflater();

                // inflate and set the layout for the dialog
                // pass null as the parent view because its going in the dialog layout
                builder.setView(inflater.inflate(R.layout.dialog_signin, null))

                // action buttons
                .setPositiveButton("Login", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // your sign in code here
                        /////////////////////////////
//                        String url = "http://68.183.207.74/api/v1/account/login/";
//                        mQueue = Volley.newRequestQueue(getActivity());
//
//                        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
//                            @Override
//                            public void onResponse(String response) {
//                                try {
//                                    JSONObject objet = new  JSONObject(response);
//                                    final JSONObject content = objet.getJSONObject("content");
//                                    User user = new User()
//                                };
//
//                            }
//                        });
//                        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, null,
//                                new Response.Listener<JSONObject>() {
//                                    @Override
//                                    public void onResponse(JSONObject response) {
//                                        try {
//
//                                            JSONArray jsonArray_modele = response.getJSONArray("content");
//
//                                            for (int i = 0 ; i < jsonArray_modele.length(); i++){
//                                                JSONObject modele = jsonArray_modele.getJSONObject(i);
//                                                modeles.add(modele.getString("name"));
//
//                                                ArrayAdapter modelesAdapter =  new ArrayAdapter<String>(
//                                                        getActivity(), android.R.layout.simple_list_item_1, modeles);
//                                                listModeles.setAdapter(modelesAdapter);
//                                            }
//                                        } catch (JSONException e) {
//                                            e.printStackTrace();
//                                        }
//                                    }
//                                }, new Response.ErrorListener() {
//                            @Override
//                            public void onErrorResponse(VolleyError error) {
//                                error.printStackTrace();
//                            }
//                        });
//                        mQueue.add(request);
                        /////////////////////////////





                        Intent intent = new Intent(getContext(), VendreActivity.class);
                        intent.putExtra("annee_tv", annee[0]);
                        intent.putExtra("klmt_tv", klmn);
                        intent.putExtra("prix_tv", prix);
                        intent.putExtra("transm_tv", transmission[0]);
                        intent.putExtra("prop", vendu_own);
                        startActivity(intent);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // remove the dialog from the screen
                    }
                })
                .show();

            }
        });

        return root;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(FormulaireAjoutOffreViewModel.class);
        // TODO: Use the ViewModel
    }

}
