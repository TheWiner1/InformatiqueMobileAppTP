package ca.ulaval.ima.tp3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ListeModelesActivity extends AppCompatActivity {

    ///////////////
    private void jsonParse(){

    }
///////
    private RequestQueue mQueue;
    ArrayList<String> modeles = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_modeles);


        final ListView listModeles = findViewById(R.id.listeModeles_v);

        mQueue = Volley.newRequestQueue(this);

        Intent intent = getIntent();
        String id = intent.getStringExtra("id");

        String url = "http://68.183.207.74/api/v1/brand/" + id + "/models/";
        //String url = "http://68.183.207.74/api/v1/brand/1/models/";

        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                            JSONArray jsonArray_modele = response.getJSONArray("content");

                            for (int i = 0 ; i < jsonArray_modele.length(); i++){
                                JSONObject modele = jsonArray_modele.getJSONObject(i);
                                modeles.add(modele.getString("name"));

                                ArrayAdapter modelesAdapter =  new ArrayAdapter<String>(
                                        ListeModelesActivity.this, android.R.layout.simple_list_item_1, modeles);
                                listModeles.setAdapter(modelesAdapter);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);

        listModeles.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ListeModelesActivity.this, DescriptionOffre.class);
                intent.putExtra("id_model", position + 1 +"");
                startActivity(intent);
            }
        });

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setTitle("Modèles de voiture");

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
