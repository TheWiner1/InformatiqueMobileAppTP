package ca.ulaval.ima.tp3.ui.main;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.util.List;

import ca.ulaval.ima.tp3.R;

/**
 * Created by mathieu on 2017-02-21.
 */

public class CountryRecyclerViewAdapter extends RecyclerView.Adapter<CountryRecyclerViewAdapter.ViewHolder> {
    private static final String ASSETS_DIR = "images/";
    private List<Country> countryList;
    private Context mContext;
    private OnCountryClickListener onCountryClickListener;

    private static final int SMALL_CELL_TYPE=0;
    private static final int LARGE_CELL_TYPE=1;
    public CountryRecyclerViewAdapter(Context context, List<Country> countryList) {
        this.countryList = countryList;
        this.mContext = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = null;
        switch (viewType){
            case SMALL_CELL_TYPE:
                view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_item, viewGroup,false);
                break;
            case LARGE_CELL_TYPE:
                view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_item_large, viewGroup,false);
                break;
        }

        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public int getItemViewType(int position) {
        // Just as an example, return 0 or 2 depending on position
        // Note that unlike in ListView adapters, types don't have to be contiguous
        Country country = countryList.get(position);

        if (country.abbreviation.equals("CA") || country.abbreviation.equals("US")){
            return LARGE_CELL_TYPE;
        }else{
            return SMALL_CELL_TYPE;
        }

    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int i) {
        final Country country = countryList.get(i);
        holder.mItem = country;
        holder.mCountryName.setText(country.name);
        holder.mCountryAbbreviation.setText(country.abbreviation);
        String imgFilePath = ASSETS_DIR + country.resourceId;
        try {
            Bitmap bitmap = BitmapFactory.decodeStream(holder.mView.getContext().getResources().getAssets().open(imgFilePath));
            holder.mFlagImageView.setImageBitmap(bitmap);
        }catch (IOException e) {
            e.printStackTrace();
        }

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCountryClickListener.onCountryClick(country);
            }
        };
        holder.mView.setOnClickListener(listener);

    }

    @Override
    public int getItemCount() {
        return countryList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView mCountryName;
        public final TextView mCountryAbbreviation;
        public final ImageView mFlagImageView;
        public Country mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mCountryName = (TextView) view.findViewById(R.id.country_name);
            mCountryAbbreviation = (TextView) view.findViewById(R.id.country_abbrev);
            mFlagImageView = (ImageView) view.findViewById(R.id.country_icon);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mCountryName.getText() + "'";
        }
    }





    public OnCountryClickListener getOnItemClickListener() {
        return onCountryClickListener;
    }

    public void setOnCountryClickListener(OnCountryClickListener onItemClickListener) {
        this.onCountryClickListener = onItemClickListener;
    }

    public interface OnCountryClickListener {
        void onCountryClick(Country item);
    }
}
