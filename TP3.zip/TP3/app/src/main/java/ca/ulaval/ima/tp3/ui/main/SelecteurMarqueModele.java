package ca.ulaval.ima.tp3.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import ca.ulaval.ima.tp3.R;

public class SelecteurMarqueModele extends Fragment {

    private SelecteurMarqueModeleViewModel mViewModel;

    public static SelecteurMarqueModele newInstance() {
        return new SelecteurMarqueModele();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.selecteur_marque_modele_fragment, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(SelecteurMarqueModeleViewModel.class);
        // TODO: Use the ViewModel
    }

}
