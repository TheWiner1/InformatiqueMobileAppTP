package ca.ulaval.ima.tp3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class VendreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendre);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        String nom = "Vendre une voiture";
        getSupportActionBar().setTitle(nom);

        Intent intent = getIntent();

        TextView marque_tv, modele_tv, annee_tv, klmt_tv, transm_tv, prix_tv, vendeur_tv, propr_tv, desc_tv;
        marque_tv = findViewById(R.id.v_marque);
        modele_tv = findViewById(R.id.v_modele);
        annee_tv = findViewById(R.id.v_annee);
        klmt_tv = findViewById(R.id.v_klmt);
        transm_tv = findViewById(R.id.v_transm);
        prix_tv = findViewById(R.id.v_prix);
        vendeur_tv = findViewById(R.id.v_nom);
        propr_tv = findViewById(R.id.v_proprie);
        desc_tv = findViewById(R.id.v_desc);


        marque_tv.setText(intent.getStringExtra("marque_tv"));
        modele_tv.setText(intent.getStringExtra("modele_tv"));
        annee_tv.setText(intent.getStringExtra("annee_tv"));
        klmt_tv.setText(intent.getStringExtra("klmt_tv"));
        transm_tv.setText(intent.getStringExtra("transm_tv"));
        prix_tv.setText(intent.getStringExtra("prix_tv"));
        vendeur_tv.setText(intent.getStringExtra("vendeur_tv"));
        propr_tv.setText(intent.getStringExtra("prop"));
        desc_tv.setText(intent.getStringExtra("desc_tv"));

        ImageView img = findViewById(R.id.v_image);
        Picasso.get().load(intent.getStringExtra("urimg")).into(img);


        Button btnvontacer = findViewById(R.id.button);
        btnvontacer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendEmail();
            }
        });


//        marque_tv.setText("marque_tv");
//        modele_tv.setText("modele_tv");
//        annee_tv.setText("annee_tv");
//        klmt_tv.setText("klmt_tv");
//        transm_tv.setText("transm_tv");
//        prix_tv.setText("prix_tv");
//        vendeur_tv.setText("vendeur_tv");
//        propr_tv.setText("prop");
//        desc_tv.setText("desc_tv");

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    protected void sendEmail() {
        Log.i("Send email", "");
        String[] TO = {""};
        String[] CC = {""};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);

        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Your subject");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "Email message goes here");

        try {
            startActivity(Intent.createChooser(emailIntent, "Send mail..."));
            finish();
            Log.i("Finished sending email.", "");
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(VendreActivity.this, "There is no email client installed.", Toast.LENGTH_SHORT).show();
        }
    }
}
