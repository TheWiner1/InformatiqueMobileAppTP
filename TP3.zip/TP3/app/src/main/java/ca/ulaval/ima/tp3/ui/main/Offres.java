package ca.ulaval.ima.tp3.ui.main;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONException;
import org.json.JSONObject;

//TODO
public class Offres implements Parcelable {

    public int id;
    public String name;

    public Offres(JSONObject content) throws JSONException {
        this.id = content.getInt("id");
        this.name = content.getString("name");
    }

    protected Offres(Parcel in) {
        id = in.readInt();
        name = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
    }

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Offres> CREATOR = new Parcelable.Creator<Offres>() {
        @Override
        public Offres createFromParcel(Parcel in) {
            return new Offres(in);
        }

        @Override
        public Offres[] newArray(int size) {
            return new Offres[size];
        }
    };
}
