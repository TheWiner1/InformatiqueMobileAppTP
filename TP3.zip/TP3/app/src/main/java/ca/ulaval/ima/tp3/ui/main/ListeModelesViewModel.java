package ca.ulaval.ima.tp3.ui.main;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.lifecycle.ViewModel;

import org.json.JSONException;
import org.json.JSONObject;

public class ListeModelesViewModel extends ViewModel implements Parcelable {
    // TODO: Implement the ViewModel

    public int id;
    public String name;
    public Offres offre;

    public ListeModelesViewModel(JSONObject content) throws JSONException {
        this.id = content.getInt("id");
        this.name = content.getString("name");
        this.offre = new Offres(content.getJSONObject("brand"));
    }

    protected ListeModelesViewModel(Parcel in) {
        id = in.readInt();
        name = in.readString();
        offre = (Offres) in.readValue(Offres.class.getClassLoader());
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeValue(offre);
    }

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<ListeModelesViewModel> CREATOR = new Parcelable.Creator<ListeModelesViewModel>() {
        @Override
        public ListeModelesViewModel createFromParcel(Parcel in) {
            return new ListeModelesViewModel(in);
        }

        @Override
        public ListeModelesViewModel[] newArray(int size) {
            return new ListeModelesViewModel[size];
        }
    };
}
