package ca.ulaval.ima.tp3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import ca.ulaval.ima.tp3.ui.main.FormulaireAjoutOffre;

public class ListeModelesAllActivity extends AppCompatActivity {
    private RequestQueue mQueue;
    ArrayList<String> modeles = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_modeles_all);

        final ListView listModeles = findViewById(R.id.listeModeles_all_v);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Modèles de voiture");

        mQueue = Volley.newRequestQueue(this);
        final String[] name = new String[1];
        String url = "http://68.183.207.74/api/v1/model/";
        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String name1, name2;

                            JSONArray jsonArray_models = response.getJSONArray("content");
                            modeles.clear();
                            for (int i = 0 ; i < jsonArray_models.length(); i++){
                                JSONObject model = jsonArray_models.getJSONObject(i);
                                modeles.add(model.getString("name"));
                                name1 = model.getString("name");
                                name2 = model.getJSONObject("brand").getString("name");

                                name[0] = name1 + name2;
                                ArrayAdapter modelesAdapter =  new ArrayAdapter<String>(
                                        ListeModelesAllActivity.this, android.R.layout.simple_list_item_1, modeles
                                );
                                listModeles.setAdapter(modelesAdapter);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);


        listModeles.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = getIntent();
                intent.putExtra("modl", name[0]);

                try {
//                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(ListeModelesAllActivity.
//                            this.openFileOutput("modele_valeur.txt", Context.MODE_APPEND));

                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(ListeModelesAllActivity.
                            this.openFileOutput("modele_valeur.txt", Context.MODE_APPEND));
                    //C:\Users\anohe\Desktop\TP3\app\src\main\assets\modele_valeur.txt

                    outputStreamWriter.write(name[0]);
                    outputStreamWriter.close();
                }
                catch (IOException e) {
                    Log.e("Exception", "File write failed: " + e.toString());
                }
                ///////////
                onBackPressed();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
