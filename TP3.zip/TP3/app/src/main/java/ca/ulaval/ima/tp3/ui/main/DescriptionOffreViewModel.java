package ca.ulaval.ima.tp3.ui.main;

import androidx.lifecycle.ViewModel;

public class DescriptionOffreViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
